## What this changes

## How it was tested

- [ ] `AP_TEST_WORLDS=anno117 python -m pytest test/general worlds/anno117/test`
- [ ] Bridge tests (`tests/lua/run_bridge_tests.py`), if the mod changed
- [ ] End-to-end tests (`tests/e2e/`), if the client or mod changed
- [ ] Played in Anno 117 (describe below), if possible

## Checklist

- [ ] Versions bumped and `CHANGELOG.md` updated, if options, logic or the bridge protocol changed
