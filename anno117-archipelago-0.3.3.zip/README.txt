Anno 117: Pax Romana for Archipelago, world 0.3.3

anno117.apworld    double-click it (or Install APWorld in the Archipelago Launcher), then open the
                   Anno 117 Client: it installs the game mod by itself
AP-Anno117.zip     the game mod, only if you want to install it by hand into Documents/Anno 117/mods
Anno 117.yaml      options template with every option explained
examples/          ready-made options files
setup_en.md        the full setup guide

Unofficial fan project, not affiliated with Ubisoft. MIT licence, see LICENSE and CREDITS.md.
